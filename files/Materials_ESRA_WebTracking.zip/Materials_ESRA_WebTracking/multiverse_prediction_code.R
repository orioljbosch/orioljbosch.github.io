##########################
## ESRA 23 SHORT COURSE ##
##########################



### INFORMATION ABOUT THE SCRIPT #####
######################################

## Task : EXPLORING THE MULTIVERSE OF RESULTS
## Country: SPAIN, PORTUGAL AND ITALY
## Date: 17/07/2023

######################################

#############################################
## INSTALL AND/OR LOAD THE NEEDED PACKAGES ##
#############################################


#Libraries and packages
#install.packages('epiDisplay')
#install.packages('data.table')
#install.packages('dplyr')
#install.packages('ggplot2')
#install.packages('randomForest')
#install.packages('rsample')


library(data.table)
library(dplyr)
library(epiDisplay)
library(ggplot2)
library(randomForest)
library(rsample)

options(scipen=999)

################################
## LOAD AND CHECK THE DATASET ##
################################

Reg_ES = fread("C:/Users/oriol/OneDrive - London School of Economics/Conferences/ESRA 2023/Short Course/reg_all_cross_spain.csv")


#Check the dataset

head(Reg_ES)
# Variable: name of the variable used to model the relationship between exposure to media, and political knowledge
# Coefficient: standardised regression coefficient obtained
# Metric: what metric was used to compute that variable
# List: what list of media outlets was used
# Top: how many of those media outlets were used
# Time_threshold: how a visit was defined (how many seconds of exposure to qualify)
# Tracking period: how many days we tracked people, and wheter before / after the survey
# Domain_Subdomain: how a URL was defined as news (all URLs in the media outlet, or only those identified as political)
# Device: what online behaviours were used (only mobile, only pc, both, and both but without tracking apps)


#####################################################################################################
## WE FIRST CAN CHECK WHETHER THE ANALYSES ARE VERY SENSITITVE TO THE WAY WE DEFINE MEDIA EXPOSURE ##
#####################################################################################################

Reg_ES %>%
  ggplot( aes(x=Coefficient)) +
  geom_histogram( binwidth=0.005, fill="#C00000", color="#e9ecef", alpha=0.7) +
  ggtitle("") +
  scale_y_continuous(name="Count", limits=c(0.0, 1000)) +
  xlab("") +
  ylab("Count") +
  theme(
    plot.title = element_text(size=13),
    axis.title.x = element_text(size=16, hjust=0.5),
    axis.title.y = element_text(size=16, hjust=0.5),
    axis.text.y = element_text(size=16),
    axis.text.x = element_text(size=16)
  )

Reg_ES[, summary(Coefficient)] 
# AVG: .08
# MEDIAN: .08
# MIN: -.02
# MAX: .15
# 1st QUART: .06  
# 3RD QUART: .10

# There seems to be quite some fluctuation


#################################################
## PREDICTING THE EFFECT OF EACH DESIGN CHOICE ##
#################################################


## First we create the train and test datasets
##############################################

Reg_ES$variable <- NULL #We do not need this variable for the modelling bit of the script

set.seed(1994)
ames_split <- initial_split(Reg_ES, prop = .7) #we use 70% of the sample to train the model
ames_train <- training(ames_split)
ames_test  <- testing(ames_split)

## Now the variables can be transformed into factor type

ames_train$List <- factor(ames_train$List)
ames_train$Metric <- factor(ames_train$Metric)
ames_train$Domain_Subdomain <- factor(ames_train$Domain_Subdomain)
ames_train$Device <- factor(ames_train$Device)
ames_train$Time_threshold <- factor(ames_train$Time_threshold)
ames_train$Tracking_period <- factor(ames_train$Tracking_period)
ames_train$Top <- factor(ames_train$Top)

## We can run a Random Forest of Regression Trees ##
####################################################

# Other approaches could work, but this is convenient and fairly simple to apply
# I did some testing of other specifications for the model. This seems to work quite well 

set.seed(1994) # set de seed to make it reproducible

m3 <- randomForest(
  formula = Coefficient ~ .,
  data    =  ames_train,
  sampsize = 1995,
  mtry = 4,
  nodesize = 3,
  ntree = 500,
  keep.inbag = T,
  importance= T
)

m3
## The mean squared residuals equals to something very low: 0.0002633571
## The % of variance explained equals to 92.8%


##############################################
## PLOT THE RESULTS OF THE PREDICTIVE MODEL ##
##############################################

# The predictive models helps us summarise the vast amount of information that we have
# It is not feasible to check what design decisions are more important, and in what sense using descriptive methods


### PLOT THE IMPORTANCE OF EACH DESIGN FEATURE ###
##################################################

#We can not plot the variable importance. This information  tells us which design feature is more important in the model i.e., the % increase of MSE if the variable is excluded


varImpPlot # just running varImpPlot already gives a plot with enough information

#But I want it nice, so we can plot it better

imp <- varImpPlot(m3, type = 1, scale = FALSE, main = "Variable Importance") #WE IMPORT THIS VALUE FROM THE MODEL

# this part just creates the data.frame for the plot part

imp <- as.data.frame(imp)
imp$varnames <- rownames(imp) # row names to column
rownames(imp) <- NULL  
imp$var_categ <- as.factor(ifelse(imp$varnames == "List", "List URLs",
                                  ifelse(imp$varnames == "Top", "List URLs",
                                         ifelse(imp$varnames == "Domain_Subdomain", "List URLs",
                                                ifelse(imp$varnames == "Time_threshold", "Exposure",
                                                       ifelse(imp$varnames == "Metric", "Metrics",
                                                              ifelse(imp$varnames == "Device", "Exposure",
                                                                     ifelse(imp$varnames == "App", "Exposure",
                                                                            ifelse(imp$varnames == "Tracking_period", "Time",
                                                                                   ifelse(imp$varnames == "PRE_POST", "Time",0))))))))))

# This is jsut to make the plot look nicer
ggplot(imp, aes(x=reorder(varnames, get("%IncMSE")), y=get("%IncMSE"), color=as.factor(var_categ))) + 
  geom_point(size= 2.5, show.legend=F) +
  geom_segment(aes(x=varnames,xend=varnames, y=0, yend=get("%IncMSE")), size=1, show.legend=F) +
  ggtitle("") +
  scale_color_discrete(name="Variable Group") +
  ylab("") +
  scale_y_continuous(name="", limits=c(0.0, 0.00075), n.breaks = 5) +
  theme(
    plot.title = element_text(size=13, hjust=0.5),
    axis.title.x = element_text(size=12, hjust=0.5),
    axis.title.y = element_blank(),
    axis.text.y = element_text(size=15, face="bold"),
    axis.text.x = element_text(size=15)
    
  ) +
  coord_flip()


# The graph tells us that the most important design choice is the tracking period, closely followed by the device, and the metric. 
# The list and the time_thresholds are very much not relevant


### PARTIAL DEPENDANCE PLOTS FOR EVERY VARIABLE ###
###################################################

## Now we can explore the marginal effect of each design choice
## This is "similar" to an average marginal effect in a logistic regression i.e., what would be the value if everything was hold constant and we changed the choic we made within a design feature


#We can plot these separately, and get the information we need. But I want to create a nice combined plot.
#Hence, I save all the information that I need

part_plot_list <- partialPlot(m3,ames_train, List)
part_plot_list <- as.data.frame(part_plot_list)
part_plot_list$var_categ <- rep("List") 

part_plot_Top <- partialPlot(m3,ames_train, Top)
part_plot_Top <- as.data.frame(part_plot_Top)
part_plot_Top$var_categ <- rep("Top") 

part_plot_DOMAIN_SUBDOMAIN <- partialPlot(m3,ames_train, Domain_Subdomain)
part_plot_DOMAIN_SUBDOMAIN <- as.data.frame(part_plot_DOMAIN_SUBDOMAIN)
part_plot_DOMAIN_SUBDOMAIN$var_categ <- rep("Domain or subdomain") 

part_plot_Time_threshold <- partialPlot(m3,ames_train, Time_threshold)
part_plot_Time_threshold <- as.data.frame(part_plot_Time_threshold)
part_plot_Time_threshold$var_categ <- rep("Time Threshold") 

part_plot_Level <- partialPlot(m3,ames_train, Metric)
part_plot_Level <- as.data.frame(part_plot_Level)
part_plot_Level$var_categ <- rep("Metric") 

part_plot_Device <- partialPlot(m3,ames_train, Device)
part_plot_Device <- as.data.frame(part_plot_Device)
part_plot_Device$var_categ <- rep("Device") 

part_plot_Tracking_period <- partialPlot(m3,ames_train, Tracking_period)
part_plot_Tracking_period <- as.data.frame(part_plot_Tracking_period)
part_plot_Tracking_period$var_categ <- rep("Tracking period") 


part_plot_combined <- do.call("rbind", list(part_plot_list, part_plot_Top, part_plot_DOMAIN_SUBDOMAIN,
                                            part_plot_Time_threshold, part_plot_Level,
                                            part_plot_Device, part_plot_Tracking_period)) ## combine all the information from all plots


## MAKE THE COMBINED GRAPHIC
############################

ggplot(part_plot_combined, aes(x=x, y=y, color=as.factor(var_categ))) + 
  geom_point(size= 2.5, show.legend=F) +
  geom_segment(aes(x=x,xend=x,y=0,yend=y), size=1, show.legend=F) +
  ggtitle("") +
  scale_color_discrete(name="Variable Group") +
  scale_x_discrete(limits = c("PRE2", "PRE5", "PRE10","PRE15","ALL31", " ", "PC only", "Mobile only", "All devices","All devices - web only"," ","Visit",
                              "Time","Day","Media", " ", "120", "30", "1", " ", "Subdomain", "Domain", " ", "ALL", "200",
                              "100", "50", "20", "10.", " ", "Tranco", "Majestic", "Cisco",
                              "Alexa", "ALL")) +
  ylab("") +
  scale_y_continuous(name="", limits=c(0, 0.1), n.breaks = 10) +
  theme(
    plot.title = element_text(size=13, hjust=0.5),
    axis.title.x = element_text(size=12, hjust=0.5),
    axis.title.y = element_blank(),
    axis.text.y = element_text(size=13, face="bold"),
    axis.text.x = element_text(size=15)
    
  ) +
  coord_flip()



