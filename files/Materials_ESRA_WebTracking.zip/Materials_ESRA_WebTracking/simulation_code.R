
##########################
## ESRA 23 SHORT COURSE ##
##########################



### INFORMATION ABOUT THE SCRIPT #####
######################################

## Task : SIMULATING UNDERCOVERAGE BIAS
## Country: SPAIN, PORTUGAL AND ITALY
## Date: 17/07/2023

######################################

#############################################
## INSTALL AND/OR LOAD THE NEEDED PACKAGES ##
#############################################

#Libraries and packages
#install.packages('data.table')
#install.packages('epiDisplay')
#install.packages('ggplot2')
#install.packages('dplyr')

library(data.table)
library(dplyr)
library(epiDisplay)
library(ggplot2)


################################
## LOAD AND CHECK THE DATASET ##
################################

simulation_WT = fread("C:/Users/oriol/OneDrive - London School of Economics/Conferences/ESRA 2023/Short Course/simulation_dataset.csv")

simulation_DT = setDT(simulation_WT) #set as data.table

#Check the dataset

head(simulation_DT)
# g6: ID Variable
# undercovered_device_1: identifies who is not fully covered and who is (1= fully; 2= not fully)
# num_devices_tracked: number of devices we are tracking
# num_device_reported_excludeother: number of devices they reported using (excluding other types of devices that we do not care about such as smart tv)
# ALL_T_Internet_M: seconds we observed them spending on the Internet with mobile devices
# ALL_T_Internet_P: seconds we observed them spending on the Internet with desktop/laptop devices
# ALL_T_Internet_TRUE: seconds we observed them spending on the Internet with all devices 
# device_simulation_inclusion: fully tracked participants that we can use for the simulation
# device_simulation_inclusion_PCMOB: fully tracked participants that we can use for the simulation, which use both PC and mobile devices

simulation_DT[, tab1(undercovered_device_1)] #74% of the sample is undercovered to some extent

############################
## CREATING THE FUNCTIONS ##
############################

# Now we can create a function to simulate whatever scenario of undercoverage that we might be interested in
# For this example, I use a very basic approach. And I only simulate the effect of, with equal probability, having either all PCs or all Mobile devices not tracked
# Other approaches can be used. And more complex scenarios can be tested. But this is just a taste.


## SCENARIO BIAS ##
###################


### AVERAGE TIME SPENT ON THE INTERNET
######################################

##PC UNDERCOVERAGE

Internet_P_function = function(proba) {
  
  simulation_DT[device_simulation_inclusion_PCMOB ==1, test_var8 := rbinom(435,size=1,prob=proba)] #here, randomly, the 435 eligible participants will get assigned value 1 (fully covered), or value 0 (undercovered)
  
  simulation_DT[, ALL_T_Internet_P_under_proba := fcase(device_simulation_inclusion_PCMOB ==1, ALL_T_Internet_P*test_var8, #those undercovered lose all their information from PC devices (value multiplied by 0)
                                                        device_simulation_inclusion_PCMOB == 0, ALL_T_Internet_P)] #those that are fully tracked but only use one device cannot be undercovered, so their value is not affected
  
  simulation_DT[, ALL_T_Internet_simulated_proba := fcase (device_simulation_inclusion_PCMOB ==1, ALL_T_Internet_M + ALL_T_Internet_P_under_proba, 
                                                           device_simulation_inclusion_PCMOB == 0, ALL_T_Internet_TRUE)]
  
  a<- simulation_DT[device_simulation_inclusion ==1, mean(ALL_T_Internet_simulated_proba)] 
  return(a)
}



#MOBILE UNDERCOVERAGE

Internet_M_function = function(proba) {
  
  simulation_DT[device_simulation_inclusion_PCMOB ==1, test_var8 := rbinom(435,size=1,prob=proba)]
  
  simulation_DT[, ALL_T_Internet_M_under_proba := fcase(device_simulation_inclusion_PCMOB ==1, ALL_T_Internet_M*test_var8, #same but in this case those elected as undercovered miss all the information from thei mobile
                                                        device_simulation_inclusion_PCMOB == 0, ALL_T_Internet_M)]
  
  simulation_DT[, ALL_T_Internet_simulated_proba := fcase (device_simulation_inclusion_PCMOB ==1, ALL_T_Internet_P + ALL_T_Internet_M_under_proba,
                                                           device_simulation_inclusion_PCMOB == 0, ALL_T_Internet_TRUE)]
  
  a<- simulation_DT[device_simulation_inclusion ==1, mean(ALL_T_Internet_simulated_proba)]
  return(a)
}



#######################################
## ANALYSES: RUNNING THE SIMULATIONS ##
#######################################


## SCENARIO BIAS ##
###################


### AVERAGE TIME SPENT ON THE INTERNET
######################################

## WHAT IS THE VALUE UDNER FULL COVERAGE?

simulation_DT[device_simulation_inclusion ==1, mean(ALL_T_Internet_TRUE/60)] # TRUE VALUE: 194.50 Minutes

##PC UNDERCOVERAGE

# Now we can run 1000 simulations for each undercoverage scenario

set.seed(1994) #set the seed to keep it reproducible
Internet_P_25 = replicate(n = 1000, expr = Internet_P_function(0.75)) #we set the probability of being fully covered ad .75 (i.e., probability of undercovered at .25). Run the function 1,000 times
Internet_P_50 = replicate(n = 1000, expr = Internet_P_function(0.50))
Internet_P_75 = replicate(n = 1000, expr = Internet_P_function(0.25))



# Now we can extract the mean of those simulations, and compare the results with the TRUE value

summ(Internet_P_25/60, graph = F) # 25% PC UNDERCOVERAGE: 181.90 Minutes <- the average minutes that people spend on the interent over the 1,000 simulations
summ(Internet_P_50/60, graph = F) # 50% PC UNDERCOVERAGE: 169.27 Minutes
summ(Internet_P_75/60, graph = F) # 75% PC UNDERCOVERAGE: 156.56 Minutes 



#MOBILE UNDERCOVERAGE

# Now we can run 1000 simulations for each undercoverage scenario

set.seed(1994)
Internet_M_25 = replicate(n = 1000, expr = Internet_M_function(0.75))
Internet_M_50 = replicate(n = 1000, expr = Internet_M_function(0.50))
Internet_M_75 = replicate(n = 1000, expr = Internet_M_function(0.25))


# Now we can extract the mean of those simulations, and compare the results with the TRUE value


summ(Internet_M_25/60, graph = F) #170.01 Minutes
summ(Internet_M_50/60, graph = F) #145.42 Minutes
summ(Internet_M_75/60, graph = F) #120.91 Minutes <- we see how, wight a probability of .75 of missing all mobile devices, we would observe an average time 73.59 minutes lower!


####################################################################################
## WE CAN PLOT THIS TO VISUALLY SHOW THE ABSOLUTE DEVIATION FROM THE "TRUE" VALUE ##
####################################################################################

Internet_Mobile_PC <- data.frame(
  value = c(Internet_P_25, Internet_P_50, Internet_P_75,
            Internet_M_25, Internet_M_50, Internet_M_75),
  Undercoverage = c(rep("25%", 1000), rep("50%", 1000), rep("75%", 1000), rep("25%", 1000), rep("50%", 1000), rep("75%", 1000)),
  Device = c(rep("PC", 3000), rep("Mobile", 3000))
)


Internet_Mobile_PC %>%
  ggplot( aes(x=(value/60), y=Undercoverage, fill=Device)) +
  geom_boxplot(width=0.6, color="black", alpha=1) +
  geom_vline(xintercept = 194.50, linetype="dotted", 
             color = "red", size=1.1) +
  theme_bw() +
  ggtitle("Average Time on the Internet") +
  xlab("Minutes")





